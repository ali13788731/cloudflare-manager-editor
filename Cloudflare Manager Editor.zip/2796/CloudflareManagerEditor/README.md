# Cloudflare Manager Editor

اپلیکیشن اندرویدی برای مدیریت Cloudflare Workers از موبایل: مشاهده، ویرایش، ذخیره و Deploy کد، به‌همراه مرور KV / D1 / R2 / DNS / Pages.

## تکنولوژی‌ها
- Kotlin + Jetpack Compose (Material 3)
- MVVM (ViewModel + StateFlow)
- Retrofit + OkHttp + kotlinx.serialization
- Room (تاریخچه نسخه‌ها و Log Viewer)
- EncryptedSharedPreferences (Android Security-Crypto) برای API Token

## ساختار پروژه

```
app/src/main/java/com/example/cfmanager/
├── CFApplication.kt          # DI ساده (بدون Hilt): می‌سازد و نگه می‌دارد repository
├── MainActivity.kt           # نقطه ورود، تم و NavGraph
├── data/
│   ├── remote/                # Retrofit API + NetworkModule (Auth Interceptor)
│   ├── local/                 # TokenStore (رمزنگاری‌شده) + Room (db/)
│   └── repository/            # CloudflareRepository - تنها منبع حقیقت برای ViewModel ها
├── ui/
│   ├── theme/                  # رنگ‌ها، تایپوگرافی (سبک VS Code Dark+)
│   ├── navigation/             # Screen.kt, NavGraph.kt, HomeShell.kt (منوی کناری)
│   ├── components/             # SyntaxHighlighter, CodeEditorView, CodeSearchBar
│   └── screens/
│       ├── login/              # ورود Token + چند اکانت
│       ├── workers/            # لیست Worker ها + جستجو
│       ├── editor/             # ویرایشگر کد + Save/Deploy + تاریخچه نسخه‌ها
│       ├── services/           # KV / D1 / R2 / DNS / Pages
│       └── settings/           # سوییچ اکانت، Log Viewer، حذف کامل داده
└── util/                       # ViewModelFactory, UndoRedoStack
```

## نحوه‌ی Build گرفتن

1. **باز کردن پروژه**: پوشه `CloudflareManagerEditor` را در Android Studio (نسخه Koala یا جدیدتر) با گزینه *Open* باز کنید.
2. **Gradle Wrapper**: این پروژه شامل `gradle-wrapper.properties` است اما فایل باینری `gradle-wrapper.jar` و اسکریپت‌های `gradlew`/`gradlew.bat` به‌دلیل نبود دسترسی شبکه در محیط تولید این پروژه ساخته نشده‌اند. اولین بار که پروژه را در Android Studio باز کنید، IDE به‌صورت خودکار این فایل‌ها را می‌سازد (یا از منوی *File > Sync Project with Gradle Files*). اگر از خط فرمان با Gradle نصب‌شده روی سیستم استفاده می‌کنید، دستور زیر را در ریشه پروژه اجرا کنید:
   ```
   gradle wrapper --gradle-version 8.7
   ```
3. **Sync**: صبر کنید Gradle Sync کامل شود (وابستگی‌های Retrofit، Room، Compose به‌صورت خودکار از Maven Central دانلود می‌شوند).
4. **اجرا روی دستگاه/شبیه‌ساز**: دکمه Run را بزنید (حداقل Android 8.0 / API 26).
5. **گرفتن APK**:
   - از منوی *Build > Build Bundle(s) / APK(s) > Build APK(s)* برای APK دیباگ.
   - برای نسخه Release: *Build > Generate Signed Bundle / APK*، یک Keystore بسازید یا انتخاب کنید، و APK امضاشده تولید می‌شود.
   - خروجی در مسیر `app/build/outputs/apk/` قرار می‌گیرد.

## دریافت API Token از Cloudflare

در داشبورد Cloudflare به مسیر **My Profile > API Tokens > Create Token** بروید و توکنی با دسترسی‌های زیر بسازید (بسته به نیاز):
- `Workers Scripts: Edit`
- `Account Settings: Read`
- `Workers KV Storage: Read`
- `D1: Read`
- `Workers R2 Storage: Read`
- `Zone: DNS: Read`
- `Cloudflare Pages: Read`

## قابلیت‌های پیاده‌سازی‌شده

- ✅ ورود با API Token، تست اتصال (`/user/tokens/verify`)، ذخیره امن با EncryptedSharedPreferences
- ✅ چند اکانت + سوییچ سریع بین آن‌ها
- ✅ لیست Workers با جستجو و حذف
- ✅ ویرایشگر کد: شماره خط، Syntax Highlighting برای JS/TS، جستجوی داخل کد، Undo/Redo، تغییر اندازه فونت، حالت تاریک/روشن
- ✅ Save (ذخیره نسخه محلی) و Deploy (آپلود به Cloudflare) با دیالوگ هشدار قبل از Deploy
- ✅ تاریخچه نسخه‌های محلی (Room) با امکان بازگردانی
- ✅ Import/Export کد (متن ساده - قابل اتصال به Storage Access Framework برای فایل واقعی)
- ✅ مرور KV Namespaces، D1 Databases، R2 Buckets، DNS Records، Pages Projects
- ✅ Log Viewer برای خطاهای شبکه/Deploy
- ✅ حذف کامل اطلاعات کاربر از تنظیمات
- ✅ منوی کناری (Drawer) + داشبورد اصلی، سبک بصری تیره شبیه VS Code

## نکات و محدودیت‌های شناخته‌شده (برای توسعه بیشتر)

- **Import/Export فایل واقعی**: توابع `exportSource()` / `importSource()` در `CodeEditorViewModel` آماده‌اند؛ برای اتصال به فایل‌سیستم واقعی باید `ActivityResultContracts.CreateDocument` / `OpenDocument` (Storage Access Framework) به `CodeEditorScreen` اضافه شود.
- **دستیار AI برای اصلاح کد**: به‌عنوان قابلیت اختیاری (بخش ۹) پیاده نشده؛ می‌توان یک اکشن جدید در نوار ابزار ویرایشگر اضافه کرد که متن انتخاب‌شده را به یک API مدل زبانی بفرستد.
- **نمایش خطاهای احتمالی کد**: هایلایتر فعلی صرفاً Syntax Highlighting است، نه یک Linter/TypeScript Language Server کامل (که نیازمند اجرای کامپایلر TS در دستگاه یا سرویس ابری است).
- **Deployment status/Rollback در سمت Cloudflare**: تاریخچه نسخه‌ها فعلاً فقط محلی (Room) است؛ برای Rollback واقعی به نسخه‌ی قبلیِ *دیپلوی‌شده در Cloudflare* باید از endpoint مربوط به Deployments استفاده و نسخه انتخابی مجدداً Deploy شود (ساختار پایه‌ی این endpoint در `CloudflareApi.getDeployments` موجود است).
- **آیکون برنامه**: یک آیکون Vector ساده و جایگزین قرار داده شده؛ پیشنهاد می‌شود با Image Asset Studio (راست‌کلیک روی `res` > New > Image Asset) آیکون نهایی را بسازید.

## امنیت
- تمام ترافیک فقط HTTPS (`network_security_config.xml`)
- توکن‌ها هرگز در کد، لاگ سطح BODY یا بکاپ ابری/انتقال دستگاه قرار نمی‌گیرند (`data_extraction_rules.xml`)
- دیالوگ هشدار اجباری قبل از هر Deploy
