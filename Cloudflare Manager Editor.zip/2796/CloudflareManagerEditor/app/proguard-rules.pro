# Keep Retrofit / Kotlinx Serialization models
-keepattributes *Annotation*, InnerClasses
-keep,includedescriptorclasses class com.example.cfmanager.**$$serializer { *; }
-keepclassmembers class com.example.cfmanager.** {
    *** Companion;
}
-keepclasseswithmembers class com.example.cfmanager.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-dontwarn okhttp3.**
-dontwarn retrofit2.**
