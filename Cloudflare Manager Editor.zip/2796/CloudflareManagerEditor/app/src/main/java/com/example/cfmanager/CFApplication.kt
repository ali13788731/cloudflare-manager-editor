package com.example.cfmanager

import android.app.Application
import com.example.cfmanager.data.local.TokenStore
import com.example.cfmanager.data.local.db.AppDatabase
import com.example.cfmanager.data.remote.NetworkModule
import com.example.cfmanager.data.repository.CloudflareRepository

/**
 * Minimal manual dependency container (no DI framework, to keep the project
 * easy to open and build). [repository] is the single object every ViewModel
 * needs; it's constructed lazily the first time it's touched.
 */
class CFApplication : Application() {

    lateinit var tokenStore: TokenStore
        private set

    lateinit var repository: CloudflareRepository
        private set

    override fun onCreate() {
        super.onCreate()
        tokenStore = TokenStore(this)
        val api = NetworkModule.create(tokenStore)
        val db = AppDatabase.get(this)
        repository = CloudflareRepository(api, tokenStore, db)
    }
}
