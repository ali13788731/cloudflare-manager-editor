package com.example.cfmanager.data.local

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

@Serializable
data class CFAccountCredential(
    val label: String,       // user-chosen nickname, e.g. "Personal", "Company"
    val apiToken: String,
    val accountId: String? = null // resolved after verify/list-accounts
)

/**
 * Secure, on-device storage for Cloudflare API tokens using
 * EncryptedSharedPreferences (AES-256-GCM, key held in the Android Keystore).
 * Tokens never touch app-internal plain files, logs, or backups
 * (see data_extraction_rules.xml).
 *
 * Supports multiple stored accounts and tracks which one is "active".
 */
class TokenStore(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "secure_token_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val json = Json { ignoreUnknownKeys = true }

    private companion object {
        const val KEY_ACCOUNTS = "cf_accounts_json"
        const val KEY_ACTIVE_LABEL = "cf_active_label"
    }

    fun getAllAccounts(): List<CFAccountCredential> {
        val raw = prefs.getString(KEY_ACCOUNTS, null) ?: return emptyList()
        return runCatching { json.decodeFromString<List<CFAccountCredential>>(raw) }.getOrDefault(emptyList())
    }

    fun saveAccount(credential: CFAccountCredential) {
        val current = getAllAccounts().filterNot { it.label == credential.label }
        val updated = current + credential
        prefs.edit().putString(KEY_ACCOUNTS, json.encodeToString(updated)).apply()
        if (getActiveLabel() == null) setActiveLabel(credential.label)
    }

    fun removeAccount(label: String) {
        val updated = getAllAccounts().filterNot { it.label == label }
        prefs.edit().putString(KEY_ACCOUNTS, json.encodeToString(updated)).apply()
        if (getActiveLabel() == label) {
            prefs.edit().remove(KEY_ACTIVE_LABEL).apply()
            updated.firstOrNull()?.let { setActiveLabel(it.label) }
        }
    }

    fun setActiveLabel(label: String) {
        prefs.edit().putString(KEY_ACTIVE_LABEL, label).apply()
    }

    fun getActiveLabel(): String? = prefs.getString(KEY_ACTIVE_LABEL, null)

    fun getActiveAccount(): CFAccountCredential? {
        val label = getActiveLabel() ?: return null
        return getAllAccounts().firstOrNull { it.label == label }
    }

    fun getActiveToken(): String? = getActiveAccount()?.apiToken

    /** Wipes every stored token/account. Used by "Delete all user data" in Settings. */
    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
