package com.example.cfmanager.data.local.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkerVersionDao {
    @Query("SELECT * FROM worker_versions WHERE accountLabel = :accountLabel AND scriptName = :scriptName ORDER BY createdAt DESC")
    fun observeVersions(accountLabel: String, scriptName: String): Flow<List<WorkerVersionEntity>>

    @Insert
    suspend fun insert(version: WorkerVersionEntity): Long

    @Query("DELETE FROM worker_versions WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("""
        DELETE FROM worker_versions WHERE id IN (
            SELECT id FROM worker_versions
            WHERE accountLabel = :accountLabel AND scriptName = :scriptName
            ORDER BY createdAt DESC LIMIT -1 OFFSET :keep
        )
    """)
    suspend fun trimTo(accountLabel: String, scriptName: String, keep: Int)
}

@Dao
interface AppLogDao {
    @Query("SELECT * FROM app_logs ORDER BY createdAt DESC LIMIT 200")
    fun observeLogs(): Flow<List<AppLogEntity>>

    @Insert
    suspend fun insert(log: AppLogEntity)

    @Query("DELETE FROM app_logs")
    suspend fun clear()
}
