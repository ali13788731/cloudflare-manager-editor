package com.example.cfmanager.data.local.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/** A saved snapshot of a worker's source, so the user can roll back locally. */
@Entity(tableName = "worker_versions")
data class WorkerVersionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val accountLabel: String,
    val scriptName: String,
    val source: String,
    val note: String,       // e.g. "before deploy", "manual save"
    val createdAt: Long
)

/** Simple local log for the in-app Log Viewer (errors from save/deploy/network calls). */
@Entity(tableName = "app_logs")
data class AppLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val level: String,      // INFO / WARN / ERROR
    val tag: String,
    val message: String,
    val createdAt: Long
)
