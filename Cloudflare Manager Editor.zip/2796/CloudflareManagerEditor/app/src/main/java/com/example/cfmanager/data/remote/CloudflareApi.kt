package com.example.cfmanager.data.remote

import com.example.cfmanager.data.remote.dto.*
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

/**
 * Thin wrapper around Cloudflare's REST API v4 (https://api.cloudflare.com/client/v4).
 * Auth is injected per-request via an OkHttp interceptor (see NetworkModule) reading
 * the currently active account's Bearer token from the encrypted TokenStore, so no
 * token is ever hard-coded or passed as a plain header here.
 */
interface CloudflareApi {

    // ---- Auth / identity ----
    @GET("user/tokens/verify")
    suspend fun verifyToken(): Response<CFEnvelope<CFTokenVerifyResult>>

    @GET("accounts")
    suspend fun listAccounts(): Response<CFEnvelope<List<CFAccount>>>

    // ---- Workers ----
    @GET("accounts/{accountId}/workers/scripts")
    suspend fun listWorkers(@Path("accountId") accountId: String): Response<CFEnvelope<List<CFWorker>>>

    @GET("accounts/{accountId}/workers/scripts/{scriptName}")
    suspend fun getWorkerScript(
        @Path("accountId") accountId: String,
        @Path("scriptName") scriptName: String
    ): Response<ResponseBody> // raw JS/TS source, not JSON-wrapped

    @PUT("accounts/{accountId}/workers/scripts/{scriptName}")
    suspend fun uploadWorkerScript(
        @Path("accountId") accountId: String,
        @Path("scriptName") scriptName: String,
        @Body body: RequestBody // multipart metadata+script, built in repository
    ): Response<CFEnvelope<CFWorker>>

    @DELETE("accounts/{accountId}/workers/scripts/{scriptName}")
    suspend fun deleteWorker(
        @Path("accountId") accountId: String,
        @Path("scriptName") scriptName: String
    ): Response<CFEnvelope<Unit>>

    @GET("accounts/{accountId}/workers/scripts/{scriptName}/deployments")
    suspend fun getDeployments(
        @Path("accountId") accountId: String,
        @Path("scriptName") scriptName: String
    ): Response<ResponseBody>

    // ---- KV ----
    @GET("accounts/{accountId}/storage/kv/namespaces")
    suspend fun listKvNamespaces(@Path("accountId") accountId: String): Response<CFEnvelope<List<CFKVNamespace>>>

    // ---- D1 ----
    @GET("accounts/{accountId}/d1/database")
    suspend fun listD1Databases(@Path("accountId") accountId: String): Response<CFEnvelope<List<CFD1Database>>>

    // ---- R2 ----
    @GET("accounts/{accountId}/r2/buckets")
    suspend fun listR2Buckets(@Path("accountId") accountId: String): Response<CFEnvelope<List<CFR2Bucket>>>

    // ---- DNS ----
    @GET("zones")
    suspend fun listZones(): Response<CFEnvelope<List<CFZone>>>

    @GET("zones/{zoneId}/dns_records")
    suspend fun listDnsRecords(@Path("zoneId") zoneId: String): Response<CFEnvelope<List<CFDnsRecord>>>

    // ---- Pages ----
    @GET("accounts/{accountId}/pages/projects")
    suspend fun listPagesProjects(@Path("accountId") accountId: String): Response<CFEnvelope<List<CFPagesProject>>>
}
