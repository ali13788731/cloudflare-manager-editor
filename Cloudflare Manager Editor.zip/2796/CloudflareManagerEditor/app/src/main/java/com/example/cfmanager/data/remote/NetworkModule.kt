package com.example.cfmanager.data.remote

import com.example.cfmanager.data.local.TokenStore
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Builds a singleton Retrofit/OkHttp client. The auth interceptor reads the
 * active account's token from [TokenStore] (EncryptedSharedPreferences) on
 * every request, so the token is never embedded in code or logs.
 */
object NetworkModule {

    private const val BASE_URL = "https://api.cloudflare.com/client/v4/"

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    fun create(tokenStore: TokenStore): CloudflareApi {
        val authInterceptor = okhttp3.Interceptor { chain ->
            val token = tokenStore.getActiveToken()
            val request = chain.request().newBuilder().apply {
                if (!token.isNullOrBlank()) {
                    addHeader("Authorization", "Bearer $token")
                }
                addHeader("Content-Type", "application/json")
            }.build()
            chain.proceed(request)
        }

        val logging = HttpLoggingInterceptor().apply {
            // Headers are deliberately not logged at BODY level in release builds
            // to avoid ever printing the Authorization header into logcat.
            level = HttpLoggingInterceptor.Level.BASIC
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

        val contentType = "application/json".toMediaType()

        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(json.asConverterFactory(contentType))
            .build()

        return retrofit.create(CloudflareApi::class.java)
    }
}
