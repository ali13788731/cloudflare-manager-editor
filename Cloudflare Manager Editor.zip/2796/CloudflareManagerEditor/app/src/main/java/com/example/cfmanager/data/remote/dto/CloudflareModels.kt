package com.example.cfmanager.data.remote.dto

import kotlinx.serialization.Serializable

/**
 * Generic Cloudflare API v4 envelope. Every endpoint returns this same
 * success/errors/messages/result shape, so we model it once and reuse it
 * for every response type via a generic type parameter.
 */
@Serializable
data class CFEnvelope<T>(
    val success: Boolean,
    val errors: List<CFError> = emptyList(),
    val messages: List<CFMessage> = emptyList(),
    val result: T? = null
)

@Serializable
data class CFError(val code: Int = 0, val message: String = "")

@Serializable
data class CFMessage(val code: Int = 0, val message: String = "")

@Serializable
data class CFTokenVerifyResult(
    val id: String = "",
    val status: String = ""
)

@Serializable
data class CFAccount(
    val id: String,
    val name: String
)

@Serializable
data class CFWorker(
    val id: String,
    val etag: String? = null,
    val modified_on: String? = null,
    val created_on: String? = null,
    // Cloudflare's list endpoint doesn't return a hard "enabled" flag directly;
    // we derive display status from usage_model / deployment presence in the repo layer.
    val usage_model: String? = null
)

@Serializable
data class CFWorkerListResult(
    val id: String? = null // placeholder, real list result is List<CFWorker> at top level
)

@Serializable
data class CFKVNamespace(
    val id: String,
    val title: String,
    val supports_url_encoding: Boolean? = null
)

@Serializable
data class CFD1Database(
    val uuid: String,
    val name: String,
    val version: String? = null,
    val num_tables: Int? = null,
    val file_size: Long? = null
)

@Serializable
data class CFR2Bucket(
    val name: String,
    val creation_date: String? = null
)

@Serializable
data class CFDnsRecord(
    val id: String,
    val type: String,
    val name: String,
    val content: String,
    val proxied: Boolean = false,
    val ttl: Int = 1
)

@Serializable
data class CFZone(
    val id: String,
    val name: String
)

@Serializable
data class CFPagesProject(
    val id: String,
    val name: String,
    val subdomain: String? = null,
    val production_branch: String? = null
)
