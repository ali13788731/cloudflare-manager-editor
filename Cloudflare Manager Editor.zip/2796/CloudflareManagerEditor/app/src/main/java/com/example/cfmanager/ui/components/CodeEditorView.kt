package com.example.cfmanager.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.cfmanager.ui.theme.EditorGutterDark
import com.example.cfmanager.ui.theme.EditorLineNumberDark
import com.example.cfmanager.ui.theme.editorTextStyle

/**
 * A code editor surface: a fixed-width line-number gutter synced to the same
 * scroll state as an editable, syntax-highlighted text field. Both panes
 * share one vertical ScrollState so numbers stay aligned to their line.
 */
@Composable
fun CodeEditorView(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    fontSizeSp: Int,
    modifier: Modifier = Modifier,
    highlightRangeInLine: IntRange? = null // used by search to highlight current match
) {
    val scrollState = rememberScrollState()
    val lineCount = remember(value.text) { value.text.count { it == '\n' } + 1 }
    val textStyle = editorTextStyle(fontSizeSp)

    Row(modifier = modifier.background(MaterialTheme.colorScheme.background)) {
        // Gutter: line numbers
        Column(
            modifier = Modifier
                .background(EditorGutterDark)
                .verticalScroll(scrollState)
                .padding(vertical = 8.dp, horizontal = 6.dp)
                .widthIn(min = 36.dp)
        ) {
            for (i in 1..lineCount) {
                Text(
                    text = i.toString(),
                    color = EditorLineNumberDark,
                    style = textStyle,
                    textAlign = androidx.compose.ui.text.style.TextAlign.End,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Editable + highlighted code
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .weight(1f)
                .verticalScroll(scrollState)
                .padding(8.dp),
            textStyle = textStyle.copy(color = MaterialTheme.colorScheme.onBackground), // overridden per-token by visualTransformation spans
            cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary),
            visualTransformation = { text ->
                TransformedText(SyntaxHighlighter.highlight(text.text), OffsetMapping.Identity)
            }
        )
    }
}
