package com.example.cfmanager.ui.navigation

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.cfmanager.data.repository.CloudflareRepository
import com.example.cfmanager.ui.screens.services.ServicesScreen
import com.example.cfmanager.ui.screens.services.ServicesViewModel
import com.example.cfmanager.ui.screens.settings.SettingsScreen
import com.example.cfmanager.ui.screens.settings.SettingsViewModel
import com.example.cfmanager.ui.screens.workers.WorkerListScreen
import com.example.cfmanager.ui.screens.workers.WorkerListViewModel
import com.example.cfmanager.util.SimpleViewModelFactory
import kotlinx.coroutines.launch

private enum class HomeTab(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    DASHBOARD("داشبورد", Icons.Filled.Dashboard),
    WORKERS("Workers", Icons.Filled.Code),
    SERVICES("سرویس‌ها", Icons.Filled.Storage),
    SETTINGS("تنظیمات", Icons.Filled.Settings)
}

/**
 * Main app shell after login: a side drawer (VS Code Activity Bar style) that
 * switches between a small dashboard, the worker list, service browsers, and
 * settings — without leaving the "home" level of the nav stack. Opening a
 * worker pushes the full-screen editor on top via [onOpenWorker].
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeShell(
    repository: CloudflareRepository,
    accountId: String,
    accountLabel: String,
    darkMode: Boolean,
    onDarkModeChange: (Boolean) -> Unit,
    onOpenWorker: (String) -> Unit,
    onLoggedOutCompletely: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(HomeTab.DASHBOARD) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val workerListViewModel: WorkerListViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = SimpleViewModelFactory(repository) { WorkerListViewModel(it) }
    )
    val servicesViewModel: ServicesViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = SimpleViewModelFactory(repository) { ServicesViewModel(it) }
    )
    val settingsViewModel: SettingsViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = SimpleViewModelFactory(repository) { SettingsViewModel(it) }
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Cloudflare Manager", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(accountLabel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Divider()
                HomeTab.entries.forEach { tab ->
                    NavigationDrawerItem(
                        icon = { Icon(tab.icon, contentDescription = null) },
                        label = { Text(tab.label) },
                        selected = selectedTab == tab,
                        onClick = {
                            selectedTab = tab
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        }
    ) {
        when (selectedTab) {
            HomeTab.DASHBOARD -> DashboardScreen(
                accountLabel = accountLabel,
                onOpenDrawer = { scope.launch { drawerState.open() } },
                onGoWorkers = { selectedTab = HomeTab.WORKERS },
                onGoServices = { selectedTab = HomeTab.SERVICES }
            )
            HomeTab.WORKERS -> WorkerListScreen(
                viewModel = workerListViewModel,
                accountId = accountId,
                onOpenWorker = onOpenWorker,
                onOpenServices = { selectedTab = HomeTab.SERVICES },
                onOpenSettings = { selectedTab = HomeTab.SETTINGS }
            )
            HomeTab.SERVICES -> ServicesScreen(
                viewModel = servicesViewModel,
                accountId = accountId,
                onBack = { selectedTab = HomeTab.DASHBOARD }
            )
            HomeTab.SETTINGS -> SettingsScreen(
                viewModel = settingsViewModel,
                darkMode = darkMode,
                onDarkModeChange = onDarkModeChange,
                onLoggedOutCompletely = onLoggedOutCompletely
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DashboardScreen(
    accountLabel: String,
    onOpenDrawer: () -> Unit,
    onGoWorkers: () -> Unit,
    onGoServices: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("داشبورد") },
                navigationIcon = { IconButton(onClick = onOpenDrawer) { Icon(Icons.Filled.Menu, contentDescription = "منو") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("خوش آمدید، $accountLabel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            ElevatedCard(onClick = onGoWorkers, modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Code, contentDescription = null)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("مدیریت Workers", fontWeight = FontWeight.SemiBold)
                        Text("مشاهده، ویرایش و Deploy اسکریپت‌ها", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            ElevatedCard(onClick = onGoServices, modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Storage, contentDescription = null)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("سرویس‌های Cloudflare", fontWeight = FontWeight.SemiBold)
                        Text("KV · D1 · R2 · DNS · Pages", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
