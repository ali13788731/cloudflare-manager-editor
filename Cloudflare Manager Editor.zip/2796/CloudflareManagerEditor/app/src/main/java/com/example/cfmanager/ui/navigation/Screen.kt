package com.example.cfmanager.ui.navigation

sealed class Screen(val route: String) {
    data object Login : Screen("login")
    data object Workers : Screen("workers")
    data object Services : Screen("services")
    data object Settings : Screen("settings")
    data object Editor : Screen("editor/{scriptName}") {
        fun createRoute(scriptName: String) = "editor/$scriptName"
    }
}
