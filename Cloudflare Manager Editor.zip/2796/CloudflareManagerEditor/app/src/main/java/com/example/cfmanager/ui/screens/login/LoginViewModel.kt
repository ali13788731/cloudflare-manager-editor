package com.example.cfmanager.ui.screens.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cfmanager.data.local.CFAccountCredential
import com.example.cfmanager.data.repository.ApiResult
import com.example.cfmanager.data.repository.CloudflareRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class LoginUiState {
    data object Idle : LoginUiState()
    data object Loading : LoginUiState()
    data class Success(val account: CFAccountCredential) : LoginUiState()
    data class Error(val message: String) : LoginUiState()
}

class LoginViewModel(private val repository: CloudflareRepository) : ViewModel() {

    private val _uiState = MutableStateFlow<LoginUiState>(LoginUiState.Idle)
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    val savedAccounts get() = repository.savedAccounts()

    fun connect(label: String, apiToken: String) {
        if (label.isBlank() || apiToken.isBlank()) {
            _uiState.value = LoginUiState.Error("نام اکانت و API Token را وارد کنید.")
            return
        }
        viewModelScope.launch {
            _uiState.value = LoginUiState.Loading
            when (val result = repository.addAndVerifyAccount(label.trim(), apiToken.trim())) {
                is ApiResult.Success -> _uiState.value = LoginUiState.Success(result.data)
                is ApiResult.Error -> _uiState.value = LoginUiState.Error(result.message)
            }
        }
    }

    fun switchAccount(label: String) {
        repository.switchAccount(label)
    }

    fun removeAccount(label: String) {
        repository.removeAccount(label)
    }

    fun resetState() {
        _uiState.value = LoginUiState.Idle
    }
}
