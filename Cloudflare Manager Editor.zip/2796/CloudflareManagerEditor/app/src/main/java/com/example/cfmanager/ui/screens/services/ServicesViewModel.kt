package com.example.cfmanager.ui.screens.services

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cfmanager.data.remote.dto.*
import com.example.cfmanager.data.repository.ApiResult
import com.example.cfmanager.data.repository.CloudflareRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class ServiceTab { KV, D1, R2, DNS, PAGES }

data class ServicesUiState(
    val selectedTab: ServiceTab = ServiceTab.KV,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val kv: List<CFKVNamespace> = emptyList(),
    val d1: List<CFD1Database> = emptyList(),
    val r2: List<CFR2Bucket> = emptyList(),
    val zones: List<CFZone> = emptyList(),
    val selectedZoneId: String? = null,
    val dnsRecords: List<CFDnsRecord> = emptyList(),
    val pages: List<CFPagesProject> = emptyList()
)

/**
 * Loads each Cloudflare service lazily (only when its tab is first opened),
 * since an account may have many namespaces/databases/buckets and the user
 * might only ever check one or two of these tabs.
 */
class ServicesViewModel(private val repository: CloudflareRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(ServicesUiState())
    val uiState: StateFlow<ServicesUiState> = _uiState.asStateFlow()

    private var accountId: String = ""
    private val loadedTabs = mutableSetOf<ServiceTab>()

    fun init(accountId: String) {
        this.accountId = accountId
        selectTab(ServiceTab.KV)
    }

    fun selectTab(tab: ServiceTab) {
        _uiState.value = _uiState.value.copy(selectedTab = tab, errorMessage = null)
        if (tab !in loadedTabs) loadTab(tab)
    }

    private fun loadTab(tab: ServiceTab) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            when (tab) {
                ServiceTab.KV -> when (val r = repository.listKv(accountId)) {
                    is ApiResult.Success -> _uiState.value = _uiState.value.copy(kv = r.data)
                    is ApiResult.Error -> _uiState.value = _uiState.value.copy(errorMessage = r.message)
                }
                ServiceTab.D1 -> when (val r = repository.listD1(accountId)) {
                    is ApiResult.Success -> _uiState.value = _uiState.value.copy(d1 = r.data)
                    is ApiResult.Error -> _uiState.value = _uiState.value.copy(errorMessage = r.message)
                }
                ServiceTab.R2 -> when (val r = repository.listR2(accountId)) {
                    is ApiResult.Success -> _uiState.value = _uiState.value.copy(r2 = r.data)
                    is ApiResult.Error -> _uiState.value = _uiState.value.copy(errorMessage = r.message)
                }
                ServiceTab.DNS -> when (val r = repository.listZones()) {
                    is ApiResult.Success -> {
                        _uiState.value = _uiState.value.copy(zones = r.data)
                        r.data.firstOrNull()?.let { selectZone(it.id) }
                    }
                    is ApiResult.Error -> _uiState.value = _uiState.value.copy(errorMessage = r.message)
                }
                ServiceTab.PAGES -> when (val r = repository.listPages(accountId)) {
                    is ApiResult.Success -> _uiState.value = _uiState.value.copy(pages = r.data)
                    is ApiResult.Error -> _uiState.value = _uiState.value.copy(errorMessage = r.message)
                }
            }
            loadedTabs.add(tab)
            _uiState.value = _uiState.value.copy(isLoading = false)
        }
    }

    fun selectZone(zoneId: String) {
        _uiState.value = _uiState.value.copy(selectedZoneId = zoneId)
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            when (val r = repository.listDnsRecords(zoneId)) {
                is ApiResult.Success -> _uiState.value = _uiState.value.copy(dnsRecords = r.data)
                is ApiResult.Error -> _uiState.value = _uiState.value.copy(errorMessage = r.message)
            }
            _uiState.value = _uiState.value.copy(isLoading = false)
        }
    }

    fun refreshCurrentTab() {
        loadedTabs.remove(_uiState.value.selectedTab)
        loadTab(_uiState.value.selectedTab)
    }
}
