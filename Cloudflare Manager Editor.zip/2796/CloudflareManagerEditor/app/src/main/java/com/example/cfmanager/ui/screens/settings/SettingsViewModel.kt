package com.example.cfmanager.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cfmanager.data.repository.CloudflareRepository
import kotlinx.coroutines.launch

class SettingsViewModel(private val repository: CloudflareRepository) : ViewModel() {

    fun accounts() = repository.savedAccounts()
    fun activeLabel() = repository.activeAccountLabel()

    fun switchAccount(label: String) = repository.switchAccount(label)
    fun removeAccount(label: String) = repository.removeAccount(label)

    fun logs() = repository.observeLogs()
    fun clearLogs() {
        viewModelScope.launch { repository.clearLogs() }
    }

    fun wipeAll(onDone: () -> Unit) {
        viewModelScope.launch {
            repository.wipeAllUserData()
            onDone()
        }
    }
}
