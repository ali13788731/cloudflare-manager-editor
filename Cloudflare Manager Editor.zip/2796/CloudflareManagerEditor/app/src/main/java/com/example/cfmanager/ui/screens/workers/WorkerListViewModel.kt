package com.example.cfmanager.ui.screens.workers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cfmanager.data.remote.dto.CFWorker
import com.example.cfmanager.data.repository.ApiResult
import com.example.cfmanager.data.repository.CloudflareRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class WorkerListUiState(
    val isLoading: Boolean = false,
    val workers: List<CFWorker> = emptyList(),
    val searchQuery: String = "",
    val errorMessage: String? = null
) {
    val filtered: List<CFWorker>
        get() = if (searchQuery.isBlank()) workers
        else workers.filter { it.id.contains(searchQuery, ignoreCase = true) }
}

class WorkerListViewModel(private val repository: CloudflareRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(WorkerListUiState())
    val uiState: StateFlow<WorkerListUiState> = _uiState.asStateFlow()

    private var accountId: String? = null

    fun load(accountId: String) {
        this.accountId = accountId
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            when (val result = repository.listWorkers(accountId)) {
                is ApiResult.Success -> _uiState.value = _uiState.value.copy(isLoading = false, workers = result.data)
                is ApiResult.Error -> _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = result.message)
            }
        }
    }

    fun refresh() {
        accountId?.let { load(it) }
    }

    fun onSearchChange(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun deleteWorker(scriptName: String, onDone: () -> Unit) {
        val accId = accountId ?: return
        viewModelScope.launch {
            when (repository.deleteWorker(accId, scriptName)) {
                is ApiResult.Success -> { refresh(); onDone() }
                is ApiResult.Error -> onDone()
            }
        }
    }
}
