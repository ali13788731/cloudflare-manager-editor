package com.example.cfmanager.ui.theme

import androidx.compose.ui.graphics.Color

// Cloudflare-orange accent on a VS-Code-dark-inspired neutral scale
val CFOrange = Color(0xFFF6821F)
val CFOrangeDark = Color(0xFFCC6F1A)

val EditorBgDark = Color(0xFF1E1E1E)
val EditorSurfaceDark = Color(0xFF252526)
val EditorLineNumberDark = Color(0xFF6E7681)
val EditorGutterDark = Color(0xFF2D2D30)

val EditorBgLight = Color(0xFFFFFFFF)
val EditorSurfaceLight = Color(0xFFF3F3F3)
val EditorLineNumberLight = Color(0xFF9CA0A6)

// Syntax colors (roughly VS Code Dark+ theme)
val SyntaxKeyword = Color(0xFF569CD6)
val SyntaxString = Color(0xFFCE9178)
val SyntaxComment = Color(0xFF6A9955)
val SyntaxNumber = Color(0xFFB5CEA8)
val SyntaxFunction = Color(0xFFDCDCAA)
val SyntaxType = Color(0xFF4EC9B0)
val SyntaxDefault = Color(0xFFD4D4D4)

val StatusSuccess = Color(0xFF3FB950)
val StatusError = Color(0xFFF85149)
val StatusWarning = Color(0xFFD29922)
