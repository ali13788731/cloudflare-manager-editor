package com.example.cfmanager.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.font.FontFamily
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp

val AppTypography = Typography()

/** Monospace style used inside the code editor; font size is user-adjustable. */
fun editorTextStyle(fontSizeSp: Int) = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontSize = fontSizeSp.sp,
    lineHeight = (fontSizeSp * 1.5f).sp
)
