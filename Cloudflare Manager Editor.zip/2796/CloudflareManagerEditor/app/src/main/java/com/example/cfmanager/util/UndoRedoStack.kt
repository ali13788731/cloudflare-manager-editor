package com.example.cfmanager.util

/**
 * Simple bounded undo/redo history of text snapshots. Debounced pushes are
 * expected to be handled by the caller (e.g. only push after a pause in
 * typing) so we don't create one entry per keystroke.
 */
class UndoRedoStack(private val maxSize: Int = 100) {
    private val undoStack = ArrayDeque<String>()
    private val redoStack = ArrayDeque<String>()

    fun push(current: String) {
        if (undoStack.lastOrNull() == current) return
        undoStack.addLast(current)
        if (undoStack.size > maxSize) undoStack.removeFirst()
        redoStack.clear()
    }

    fun canUndo() = undoStack.size > 1
    fun canRedo() = redoStack.isNotEmpty()

    fun undo(): String? {
        if (!canUndo()) return null
        val last = undoStack.removeLast()
        redoStack.addLast(last)
        return undoStack.lastOrNull()
    }

    fun redo(): String? {
        val value = redoStack.removeLastOrNull() ?: return null
        undoStack.addLast(value)
        return value
    }

    fun reset(initial: String) {
        undoStack.clear()
        redoStack.clear()
        undoStack.addLast(initial)
    }
}
