package com.example.cfmanager.util

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.cfmanager.data.repository.CloudflareRepository

/** Generic factory so every screen's ViewModel(repository) constructor can be created without Hilt. */
class SimpleViewModelFactory(
    private val repository: CloudflareRepository,
    private val creator: (CloudflareRepository) -> ViewModel
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = creator(repository) as T
}
