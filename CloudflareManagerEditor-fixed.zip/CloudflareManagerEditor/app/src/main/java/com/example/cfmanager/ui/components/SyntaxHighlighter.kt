package com.example.cfmanager.ui.components

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import com.example.cfmanager.ui.theme.*

/**
 * Lightweight, dependency-free syntax highlighter for JavaScript / TypeScript.
 * It tokenizes with a single ordered regex pass (comments/strings first, so
 * keywords inside them are never re-colored) and paints each match with the
 * corresponding VS-Code-like color. Good enough for a mobile-first code
 * viewer/editor; not a full language server.
 */
object SyntaxHighlighter {

    private val KEYWORDS = setOf(
        "const", "let", "var", "function", "return", "if", "else", "for", "while",
        "do", "switch", "case", "break", "continue", "class", "extends", "new",
        "this", "import", "export", "from", "default", "async", "await", "try",
        "catch", "finally", "throw", "typeof", "instanceof", "in", "of", "yield",
        "interface", "type", "enum", "implements", "public", "private", "protected",
        "readonly", "static", "as", "null", "undefined", "true", "false", "void",
        "delete", "super", "get", "set"
    )

    private val TYPES = setOf(
        "string", "number", "boolean", "any", "unknown", "never", "object", "Array",
        "Promise", "Request", "Response", "Env", "ExecutionContext", "Record"
    )

    // Ordered: comment, string(single/double/template), number, word
    private val TOKEN_REGEX = Regex(
        """(//[^\n]*)|(/\*[\s\S]*?\*/)|("(?:[^"\\]|\\.)*")|('(?:[^'\\]|\\.)*')|(`(?:[^`\\]|\\.)*`)|(\b\d+(?:\.\d+)?\b)|([A-Za-z_$][A-Za-z0-9_$]*)"""
    )

    fun highlight(source: String, isDark: Boolean = true): AnnotatedString = buildAnnotatedString {
        append(source)
        val comment = if (isDark) SyntaxComment else SyntaxCommentLight
        val string = if (isDark) SyntaxString else SyntaxStringLight
        val number = if (isDark) SyntaxNumber else SyntaxNumberLight
        val keyword = if (isDark) SyntaxKeyword else SyntaxKeywordLight
        val type = if (isDark) SyntaxType else SyntaxTypeLight
        val function = if (isDark) SyntaxFunction else SyntaxFunctionLight
        val default = if (isDark) SyntaxDefault else SyntaxDefaultLight

        for (match in TOKEN_REGEX.findAll(source)) {
            val range = match.range
            val text = match.value
            val style: SpanStyle = when {
                match.groups[1] != null || match.groups[2] != null -> SpanStyle(color = comment)
                match.groups[3] != null || match.groups[4] != null || match.groups[5] != null -> SpanStyle(color = string)
                match.groups[6] != null -> SpanStyle(color = number)
                match.groups[7] != null -> when (text) {
                    in KEYWORDS -> SpanStyle(color = keyword)
                    in TYPES -> SpanStyle(color = type)
                    else -> if (text.isNotEmpty() && text[0].isUpperCase()) SpanStyle(color = function)
                    else SpanStyle(color = default)
                }
                else -> SpanStyle(color = default)
            }
            addStyle(style, range.first, range.last + 1)
        }
    }
}
