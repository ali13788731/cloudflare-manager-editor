package com.example.cfmanager.ui.screens.login

import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import kotlinx.coroutines.launch

/**
 * Login / account management screen.
 * - "ورود با Cloudflare" opens Cloudflare's OAuth consent page (Custom Tabs);
 *   after the user grants access, MainActivity catches the redirect and the
 *   resulting account is saved just like a verified manual token.
 * - Manual nickname + API Token entry stays as a fallback ("Test connection"
 *   calls /user/tokens/verify before the account is treated as active).
 * - Lists previously saved accounts with quick switch / remove.
 */
@Composable
fun LoginScreen(
    viewModel: LoginViewModel,
    onConnected: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var label by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    var tokenVisible by remember { mutableStateOf(false) }

    LaunchedEffect(uiState) {
        if (uiState is LoginUiState.Success) onConnected()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(Icons.Filled.CloudDone, contentDescription = null, modifier = Modifier.size(48.dp))
        Text("اتصال به Cloudflare", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        Button(
            onClick = {
                coroutineScope.launch {
                    // startOAuthLogin() returns null (and sets an Error state itself)
                    // if it couldn't be built — nothing left to swallow here anymore.
                    val url = viewModel.startOAuthLogin(label.ifBlank { "Cloudflare" })
                    if (url != null) {
                        CustomTabsIntent.Builder().build().launchUrl(context, url.toUri())
                    }
                }
            },
            enabled = uiState !is LoginUiState.Loading,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Filled.CloudDone, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("ورود با Cloudflare")
        }

        Divider()
        Text(
            "یا با API Token دستی وارد شوید — از داشبورد Cloudflare (My Profile > API Tokens). توکن به‌صورت رمزنگاری‌شده روی همین دستگاه ذخیره می‌شود.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        OutlinedTextField(
            value = label,
            onValueChange = { label = it },
            label = { Text("نام اکانت (مثلاً: شخصی، شرکت)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = token,
            onValueChange = { token = it },
            label = { Text("Cloudflare API Token") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            visualTransformation = if (tokenVisible) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                IconButton(onClick = { tokenVisible = !tokenVisible }) {
                    Icon(if (tokenVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = null)
                }
            },
            modifier = Modifier.fillMaxWidth()
        )

        if (uiState is LoginUiState.Error) {
            Text(
                (uiState as LoginUiState.Error).message,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }

        Button(
            onClick = { viewModel.connect(label, token) },
            enabled = uiState !is LoginUiState.Loading,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (uiState is LoginUiState.Loading) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
            }
            Text("تست اتصال و ورود")
        }

        val saved = viewModel.savedAccounts
        if (saved.isNotEmpty()) {
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            Text("اکانت‌های ذخیره‌شده", style = MaterialTheme.typography.titleSmall)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(saved) { acc ->
                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            viewModel.switchAccount(acc.label)
                            onConnected()
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(acc.label, fontWeight = FontWeight.SemiBold)
                                Text(
                                    acc.accountId?.let { "Account ID: ${it.take(10)}…" } ?: "تأیید نشده",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            TextButton(onClick = { viewModel.removeAccount(acc.label) }) {
                                Text("حذف")
                            }
                        }
                    }
                }
            }
        }
    }
}
