package com.example.cfmanager.ui.theme

import androidx.compose.ui.graphics.Color

// Cloudflare-orange accent on a VS-Code-dark-inspired neutral scale
val CFOrange = Color(0xFFF6821F)
val CFOrangeDark = Color(0xFFCC6F1A)

val EditorBgDark = Color(0xFF1E1E1E)
val EditorSurfaceDark = Color(0xFF252526)
val EditorLineNumberDark = Color(0xFF6E7681)
val EditorGutterDark = Color(0xFF2D2D30)

val EditorBgLight = Color(0xFFFFFFFF)
val EditorSurfaceLight = Color(0xFFF3F3F3)
val EditorLineNumberLight = Color(0xFF9CA0A6)
val EditorGutterLight = Color(0xFFEDEDED)

// Syntax colors (roughly VS Code Dark+ theme)
val SyntaxKeyword = Color(0xFF569CD6)
val SyntaxString = Color(0xFFCE9178)
val SyntaxComment = Color(0xFF6A9955)
val SyntaxNumber = Color(0xFFB5CEA8)
val SyntaxFunction = Color(0xFFDCDCAA)
val SyntaxType = Color(0xFF4EC9B0)
val SyntaxDefault = Color(0xFFD4D4D4) // legible on the dark editor background only

// Syntax colors (roughly VS Code Light+ theme) — used when the editor is in light mode.
// SyntaxDefault's near-white gray is invisible on a white background, which was the
// root cause of "code looks empty, only line numbers show" in light mode.
val SyntaxKeywordLight = Color(0xFF0000FF)
val SyntaxStringLight = Color(0xFFA31515)
val SyntaxCommentLight = Color(0xFF008000)
val SyntaxNumberLight = Color(0xFF098658)
val SyntaxFunctionLight = Color(0xFF795E26)
val SyntaxTypeLight = Color(0xFF267F99)
val SyntaxDefaultLight = Color(0xFF1E1E1E)

val StatusSuccess = Color(0xFF3FB950)
val StatusError = Color(0xFFF85149)
val StatusWarning = Color(0xFFD29922)
