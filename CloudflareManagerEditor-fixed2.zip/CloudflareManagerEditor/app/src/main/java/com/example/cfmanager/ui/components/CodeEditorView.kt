package com.example.cfmanager.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.cfmanager.ui.theme.EditorGutterDark
import com.example.cfmanager.ui.theme.EditorGutterLight
import com.example.cfmanager.ui.theme.EditorLineNumberDark
import com.example.cfmanager.ui.theme.EditorLineNumberLight
import com.example.cfmanager.ui.theme.SyntaxDefault
import com.example.cfmanager.ui.theme.SyntaxDefaultLight
import com.example.cfmanager.ui.theme.editorTextStyle

/**
 * A code editor surface: a fixed-width line-number gutter synced to the same
 * scroll state as an editable, syntax-highlighted text field. Both panes
 * share one vertical ScrollState so numbers stay aligned to their line.
 *
 * [darkMode] drives both the gutter colors and the base/plain text color so
 * they always match the syntax highlighter's palette. Previously the gutter
 * used hard-coded dark colors and the base text color came from the ambient
 * MaterialTheme while the highlighter's "plain token" color was a fixed
 * light-gray meant only for a dark background — in light mode most of the
 * code (identifiers, punctuation) rendered as light-gray-on-white and was
 * effectively invisible, leaving only the line-number gutter visible.
 */
@Composable
fun CodeEditorView(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    fontSizeSp: Int,
    darkMode: Boolean,
    modifier: Modifier = Modifier,
    highlightRangeInLine: IntRange? = null // used by search to highlight current match
) {
    val scrollState = rememberScrollState()
    val lineCount = remember(value.text) { value.text.count { it == '\n' } + 1 }
    val textStyle = editorTextStyle(fontSizeSp)

    val gutterBg = if (darkMode) EditorGutterDark else EditorGutterLight
    val lineNumberColor = if (darkMode) EditorLineNumberDark else EditorLineNumberLight
    val baseTextColor = if (darkMode) SyntaxDefault else SyntaxDefaultLight

    Row(modifier = modifier.background(MaterialTheme.colorScheme.background)) {
        // Gutter: line numbers
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .background(gutterBg)
                .verticalScroll(scrollState)
                .padding(vertical = 8.dp, horizontal = 6.dp)
                .widthIn(min = 36.dp)
        ) {
            for (i in 1..lineCount) {
                Text(
                    text = i.toString(),
                    color = lineNumberColor,
                    style = textStyle,
                    textAlign = androidx.compose.ui.text.style.TextAlign.End,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Editable + highlighted code.
        // fillMaxHeight() here is required: inside a Row, `weight(1f)` only
        // stretches the *horizontal* axis — vertically the field still wraps
        // its own text content. For a short script that leaves most of the
        // screen below the last line completely outside the field's bounds,
        // so tapping in that empty area (which visually looks like part of
        // the editor) hit nothing, never requested focus, and never opened
        // the keyboard.
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .verticalScroll(scrollState)
                .padding(8.dp),
            textStyle = textStyle.copy(color = baseTextColor), // overridden per-token by visualTransformation spans
            cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary),
            visualTransformation = { text ->
                TransformedText(SyntaxHighlighter.highlight(text.text, isDark = darkMode), OffsetMapping.Identity)
            }
        )
    }
}
