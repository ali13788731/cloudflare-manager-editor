package com.example.cfmanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import com.example.cfmanager.data.remote.oauth.CloudflareOAuthManager
import com.example.cfmanager.ui.navigation.AppNavGraph
import com.example.cfmanager.ui.theme.CFManagerTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as CFApplication

        setContent {
            CFManagerTheme {
                AppNavGraph(repository = app.repository)
            }
        }

        handleOAuthRedirect(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleOAuthRedirect(intent)
    }

    /** cfmanager://oauth/callback?code=...&state=... coming back from the OAuth authorize page. */
    private fun handleOAuthRedirect(intent: Intent?) {
        val uri: Uri = intent?.data ?: return
        if (uri.scheme != "cfmanager" || uri.host != "oauth") return
        val app = application as CFApplication
        lifecycleScope.launch {
            CloudflareOAuthManager.onRedirectReceived(uri, app.tokenStore)
        }
    }
}
