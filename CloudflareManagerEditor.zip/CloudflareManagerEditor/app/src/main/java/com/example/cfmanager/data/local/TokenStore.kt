package com.example.cfmanager.data.local

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

@Serializable
data class CFAccountCredential(
    val label: String,       // user-chosen nickname, e.g. "Personal", "Company"
    val apiToken: String,
    val accountId: String? = null // resolved after verify/list-accounts
)

/**
 * Secure, on-device storage for Cloudflare API tokens using
 * EncryptedSharedPreferences (AES-256-GCM, key held in the Android Keystore).
 * Tokens never touch app-internal plain files, logs, or backups
 * (see data_extraction_rules.xml).
 *
 * Supports multiple stored accounts and tracks which one is "active".
 */
class TokenStore(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "secure_token_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val json = Json { ignoreUnknownKeys = true }

    private companion object {
        const val KEY_ACCOUNTS = "cf_accounts_json"
        const val KEY_ACTIVE_LABEL = "cf_active_label"
        const val KEY_OAUTH_VERIFIER = "cf_oauth_pending_verifier"
        const val KEY_OAUTH_STATE = "cf_oauth_pending_state"
    }

    /** Stashes the PKCE code_verifier + state for the in-flight OAuth login attempt. */
    fun savePendingOAuth(codeVerifier: String, state: String) {
        prefs.edit()
            .putString(KEY_OAUTH_VERIFIER, codeVerifier)
            .putString(KEY_OAUTH_STATE, state)
            .apply()
    }

    /** Reads back and clears the pending PKCE verifier/state; null if none (or already used). */
    fun consumePendingOAuth(): Pair<String, String>? {
        val verifier = prefs.getString(KEY_OAUTH_VERIFIER, null)
        val state = prefs.getString(KEY_OAUTH_STATE, null)
        prefs.edit().remove(KEY_OAUTH_VERIFIER).remove(KEY_OAUTH_STATE).apply()
        return if (verifier != null && state != null) verifier to state else null
    }

    fun getAllAccounts(): List<CFAccountCredential> {
        val raw = prefs.getString(KEY_ACCOUNTS, null) ?: return emptyList()
        return runCatching { json.decodeFromString<List<CFAccountCredential>>(raw) }.getOrDefault(emptyList())
    }

    fun saveAccount(credential: CFAccountCredential) {
        val current = getAllAccounts().filterNot { it.label == credential.label }
        val updated = current + credential
        prefs.edit().putString(KEY_ACCOUNTS, json.encodeToString(updated)).apply()
        if (getActiveLabel() == null) setActiveLabel(credential.label)
    }

    fun removeAccount(label: String) {
        val updated = getAllAccounts().filterNot { it.label == label }
        prefs.edit().putString(KEY_ACCOUNTS, json.encodeToString(updated)).apply()
        if (getActiveLabel() == label) {
            prefs.edit().remove(KEY_ACTIVE_LABEL).apply()
            updated.firstOrNull()?.let { setActiveLabel(it.label) }
        }
    }

    fun setActiveLabel(label: String) {
        prefs.edit().putString(KEY_ACTIVE_LABEL, label).apply()
    }

    fun getActiveLabel(): String? = prefs.getString(KEY_ACTIVE_LABEL, null)

    fun getActiveAccount(): CFAccountCredential? {
        val label = getActiveLabel() ?: return null
        return getAllAccounts().firstOrNull { it.label == label }
    }

    fun getActiveToken(): String? = getActiveAccount()?.apiToken

    /** Wipes every stored token/account. Used by "Delete all user data" in Settings. */
    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
