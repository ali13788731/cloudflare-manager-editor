package com.example.cfmanager.data.remote.oauth

import android.net.Uri
import com.example.cfmanager.data.local.TokenStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

sealed class OAuthLoginResult {
    data class Success(val accessToken: String) : OAuthLoginResult()
    data class Error(val message: String) : OAuthLoginResult()
}

/**
 * Drives the OAuth 2.0 Authorization Code + PKCE flow against Cloudflare's
 * self-managed OAuth (see OAuthConfig.kt for setup notes).
 *
 * - [buildAuthorizationUrl] generates a fresh code_verifier/state pair,
 *   persists them (so the flow survives the app process being killed while
 *   Chrome Custom Tabs is in the foreground), and returns the URL to open.
 * - MainActivity forwards the redirect Uri it receives back into
 *   [onRedirectReceived]; any collector of [redirectResults] (LoginViewModel)
 *   picks it up and exchanges the code for a token.
 *
 * This is a plain, unauthenticated OkHttpClient — separate from
 * NetworkModule's client — because token exchange happens before we have any
 * Cloudflare bearer token to attach.
 */
object CloudflareOAuthManager {

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val _redirectResults = MutableSharedFlow<OAuthLoginResult>(extraBufferCapacity = 1)
    val redirectResults = _redirectResults.asSharedFlow()

    private var discovered: Pair<String, String>? = null // (authorizationEndpoint, tokenEndpoint)

    suspend fun buildAuthorizationUrl(tokenStore: TokenStore): String = withContext(Dispatchers.IO) {
        require(OAuthConfig.CLIENT_ID != "REPLACE_WITH_YOUR_OAUTH_CLIENT_ID" && OAuthConfig.CLIENT_ID.isNotBlank()) {
            "OAuthConfig.CLIENT_ID has not been set yet. First create an OAuth client " +
                "in the Cloudflare dashboard (Manage Account > OAuth clients > Create client) with the Redirect URL set exactly to " +
                "\"${OAuthConfig.REDIRECT_URI}\", then put the generated Client ID into OAuthConfig.CLIENT_ID. " +
                "Without this value, the Cloudflare sign-in page opens with a 404 error because client_id is invalid."
        }
        val (authorizeEndpoint, _) = discoverEndpoints()
        val verifier = Pkce.generateCodeVerifier()
        val challenge = Pkce.codeChallengeS256(verifier)
        val state = Pkce.generateState()
        tokenStore.savePendingOAuth(verifier, state)

        Uri.parse(authorizeEndpoint).buildUpon()
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("client_id", OAuthConfig.CLIENT_ID)
            .appendQueryParameter("redirect_uri", OAuthConfig.REDIRECT_URI)
            .appendQueryParameter("scope", OAuthConfig.SCOPES)
            .appendQueryParameter("state", state)
            .appendQueryParameter("code_challenge", challenge)
            .appendQueryParameter("code_challenge_method", "S256")
            .build()
            .toString()
    }

    /** Called by MainActivity when it receives the cfmanager://oauth/callback intent. */
    suspend fun onRedirectReceived(uri: Uri, tokenStore: TokenStore) {
        val code = uri.getQueryParameter("code")
        val returnedState = uri.getQueryParameter("state")
        val error = uri.getQueryParameter("error")
        val pending = tokenStore.consumePendingOAuth()

        val result = when {
            error != null -> OAuthLoginResult.Error(uri.getQueryParameter("error_description") ?: error)
            pending == null -> OAuthLoginResult.Error("Sign-in request expired; please try again.")
            returnedState != pending.second -> OAuthLoginResult.Error("Invalid state; please try signing in again.")
            code == null -> OAuthLoginResult.Error("No code was received from Cloudflare.")
            else -> exchangeCodeForToken(code, pending.first)
        }
        _redirectResults.emit(result)
    }

    private suspend fun exchangeCodeForToken(code: String, codeVerifier: String): OAuthLoginResult =
        withContext(Dispatchers.IO) {
            try {
                val (_, tokenEndpoint) = discoverEndpoints()
                val body = FormBody.Builder()
                    .add("grant_type", "authorization_code")
                    .add("code", code)
                    .add("redirect_uri", OAuthConfig.REDIRECT_URI)
                    .add("client_id", OAuthConfig.CLIENT_ID)
                    .add("code_verifier", codeVerifier)
                    .build()
                val request = Request.Builder().url(tokenEndpoint).post(body).build()
                http.newCall(request).execute().use { resp ->
                    val text = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        return@withContext OAuthLoginResult.Error("Failed to retrieve token (${resp.code}).")
                    }
                    val accessToken = JSONObject(text).optString("access_token").takeIf { it.isNotBlank() }
                        ?: return@withContext OAuthLoginResult.Error("Invalid token response.")
                    OAuthLoginResult.Success(accessToken)
                }
            } catch (e: Exception) {
                OAuthLoginResult.Error(e.message ?: "Network error during token exchange")
            }
        }

    private suspend fun discoverEndpoints(): Pair<String, String> {
        discovered?.let { return it }
        return withContext(Dispatchers.IO) {
            val request = Request.Builder().url(OAuthConfig.DISCOVERY_URL).build()
            http.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException(
                        "OAuth discovery (${OAuthConfig.DISCOVERY_URL}) failed with ${resp.code}. " +
                            "Hard-code authorizationEndpoint/tokenEndpoint from your OAuth client's dashboard page instead."
                    )
                }
                val json = JSONObject(resp.body?.string().orEmpty())
                val pair = json.getString("authorization_endpoint") to json.getString("token_endpoint")
                discovered = pair
                pair
            }
        }
    }
}
