package com.example.cfmanager.data.remote.oauth

/**
 * Fill these in after creating the OAuth client in the Cloudflare dashboard
 * (Manage Account > OAuth clients > Create client):
 *
 *  1. Response type: "code"          Grant type: "authorization_code"
 *  2. Token endpoint auth method: "none" (this is a public/PKCE client — a
 *     mobile app cannot hold a client secret, see Pkce.kt)
 *  3. Redirect URL: must exactly match [REDIRECT_URI] below.
 *  4. Scopes: pick only what the app needs, e.g. "workers-platform.edit",
 *     "workers-kv-storage.edit", "d1.read", "workers-r2.edit", "dns.edit",
 *     "pages.edit", "account.read" — these map 1:1 to API token permission
 *     names, so use the same ones the manual-token flow asked for.
 *  5. Copy the generated Client ID into [CLIENT_ID] below. There is no
 *     client secret to copy for a PKCE/public client.
 *
 * Redirect URI: Cloudflare's own examples use an https:// URL, so the safest
 * bet for a public client is a verified Android App Link (a real https://
 * page you control, configured with autoVerify + Digital Asset Links, that
 * immediately hands off to the app). A custom scheme like "cfmanager://" is
 * simpler to wire up and works on most OAuth servers, but if the dashboard
 * rejects a non-https redirect_uri when creating the client, switch this
 * constant (and the matching <intent-filter> in AndroidManifest.xml) to an
 * https:// App Link instead.
 */
object OAuthConfig {
    const val CLIENT_ID = "REPLACE_WITH_YOUR_OAUTH_CLIENT_ID"
    const val REDIRECT_URI = "cfmanager://oauth/callback"

    /** Space-separated, matching the scopes selected for the client in the dashboard. */
    const val SCOPES = "workers-platform.edit workers-kv-storage.edit d1.read workers-r2.edit dns.edit pages.edit account.read"

    /**
     * RFC 8414 discovery document. Cloudflare's own docs (Managed OAuth for
     * Access) describe this exact discovery pattern for their OAuth
     * surfaces, so we resolve the real authorize/token URLs at runtime
     * instead of hard-coding a guess. If this 404s for your account, open
     * the OAuth client's detail page in the dashboard, copy the
     * "Authorization URL" / "Token URL" shown there, and hard-code them in
     * [CloudflareOAuthManager] instead.
     */
    const val DISCOVERY_URL = "https://dash.cloudflare.com/.well-known/oauth-authorization-server"
}
