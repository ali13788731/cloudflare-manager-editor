package com.example.cfmanager.data.remote.oauth

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * RFC 7636 (PKCE) helpers. Cloudflare's self-managed OAuth requires PKCE with
 * S256 for public clients (mobile/CLI/SPA apps that cannot hold a client
 * secret), so we never store or send a client secret — a fresh verifier is
 * generated for every login attempt instead.
 */
object Pkce {

    /** 43-128 char unreserved-character string per RFC 7636 §4.1. */
    fun generateCodeVerifier(): String {
        val bytes = ByteArray(64)
        SecureRandom().nextBytes(bytes)
        return base64UrlEncode(bytes)
    }

    /** BASE64URL(SHA256(ASCII(code_verifier))) per RFC 7636 §4.2. */
    fun codeChallengeS256(verifier: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII))
        return base64UrlEncode(digest)
    }

    fun generateState(): String {
        val bytes = ByteArray(24)
        SecureRandom().nextBytes(bytes)
        return base64UrlEncode(bytes)
    }

    private fun base64UrlEncode(bytes: ByteArray): String =
        Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
}
