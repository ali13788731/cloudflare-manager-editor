package com.example.cfmanager.data.repository

import com.example.cfmanager.data.local.CFAccountCredential
import com.example.cfmanager.data.local.TokenStore
import com.example.cfmanager.data.local.db.AppDatabase
import com.example.cfmanager.data.local.db.AppLogEntity
import com.example.cfmanager.data.local.db.WorkerVersionEntity
import com.example.cfmanager.data.remote.CloudflareApi
import com.example.cfmanager.data.remote.dto.*
import com.example.cfmanager.data.remote.oauth.CloudflareOAuthManager
import com.example.cfmanager.data.remote.oauth.OAuthLoginResult
import kotlinx.coroutines.flow.Flow
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

sealed class ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>()
    data class Error(val message: String, val code: Int? = null) : ApiResult<Nothing>()
}

/**
 * Single source of truth used by every ViewModel. Wraps Retrofit calls with
 * try/catch -> ApiResult, and bridges to Room for version history + logs.
 */
class CloudflareRepository(
    private val api: CloudflareApi,
    private val tokenStore: TokenStore,
    private val db: AppDatabase
) {
    // ---- Accounts ----

    fun savedAccounts(): List<CFAccountCredential> = tokenStore.getAllAccounts()

    fun activeAccountLabel(): String? = tokenStore.getActiveLabel()

    fun switchAccount(label: String) = tokenStore.setActiveLabel(label)

    fun removeAccount(label: String) = tokenStore.removeAccount(label)

    suspend fun addAndVerifyAccount(label: String, apiToken: String): ApiResult<CFAccountCredential> {
        // Save first so the auth interceptor picks up the new token for the verify call.
        tokenStore.saveAccount(CFAccountCredential(label, apiToken))
        tokenStore.setActiveLabel(label)

        return try {
            val verify = api.verifyToken()
            if (!verify.isSuccessful || verify.body()?.success != true) {
                tokenStore.removeAccount(label)
                log("ERROR", "Auth", "Token verification failed for $label")
                return ApiResult.Error("توکن نامعتبر است یا دسترسی کافی ندارد.", verify.code())
            }
            val accountsResp = api.listAccounts()
            val firstAccountId = accountsResp.body()?.result?.firstOrNull()?.id
            val updated = CFAccountCredential(label, apiToken, firstAccountId)
            tokenStore.saveAccount(updated)
            log("INFO", "Auth", "Account '$label' verified successfully")
            ApiResult.Success(updated)
        } catch (e: Exception) {
            tokenStore.removeAccount(label)
            log("ERROR", "Auth", "Exception verifying token: ${e.message}")
            ApiResult.Error(e.message ?: "خطای ناشناخته در اتصال")
        }
    }

    /** URL to open (in Chrome Custom Tabs) to start "ورود با Cloudflare". See OAuthConfig.kt. */
    suspend fun buildOAuthAuthorizationUrl(): String = CloudflareOAuthManager.buildAuthorizationUrl(tokenStore)

    /** Emits once per completed (or failed) OAuth redirect; MainActivity feeds the redirect in. */
    val oauthRedirectResults: kotlinx.coroutines.flow.Flow<OAuthLoginResult> = CloudflareOAuthManager.redirectResults

    /** Saves the OAuth access token as a normal account — same verify+list-accounts path as a pasted API token. */
    suspend fun completeOAuthLogin(label: String, accessToken: String): ApiResult<CFAccountCredential> =
        addAndVerifyAccount(label, accessToken)

    suspend fun listAccountIds(): ApiResult<List<CFAccount>> = safeCall("Accounts") {
        api.listAccounts()
    }

    // ---- Workers ----

    suspend fun listWorkers(accountId: String): ApiResult<List<CFWorker>> = safeCall("Workers") {
        api.listWorkers(accountId)
    }

    suspend fun getWorkerSource(accountId: String, scriptName: String): ApiResult<String> {
        return try {
            val resp = api.getWorkerScript(accountId, scriptName)
            if (resp.isSuccessful) {
                ApiResult.Success(resp.body()?.string() ?: "")
            } else {
                log("ERROR", "Editor", "Failed to fetch script $scriptName (${resp.code()})")
                ApiResult.Error("دریافت کد Worker ناموفق بود.", resp.code())
            }
        } catch (e: Exception) {
            log("ERROR", "Editor", "Exception fetching script: ${e.message}")
            ApiResult.Error(e.message ?: "خطای شبکه")
        }
    }

    /**
     * Uploads (saves) a worker's script. Cloudflare's PUT endpoint expects a
     * multipart body: one part is the JS/TS source (named after the entrypoint
     * file), one part is a metadata JSON part describing the module and
     * compatibility date.
     */
    suspend fun saveWorkerScript(
        accountId: String,
        scriptName: String,
        source: String,
        isTypeScript: Boolean
    ): ApiResult<Unit> {
        return try {
            val fileName = if (isTypeScript) "worker.ts" else "worker.js"
            val metadata = JSONObject().apply {
                put("main_module", fileName)
                put("compatibility_date", "2024-01-01")
            }
            val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart(
                    "metadata", null,
                    metadata.toString().toRequestBody("application/json".toMediaType())
                )
                .addFormDataPart(
                    fileName, fileName,
                    source.toRequestBody("application+javascript".toMediaType())
                )
                .build()

            val resp = api.uploadWorkerScript(accountId, scriptName, body)

            if (resp.isSuccessful && resp.body()?.success == true) {
                log("INFO", "Deploy", "Saved & deployed '$scriptName'")
                ApiResult.Success(Unit)
            } else {
                val err = resp.body()?.errors?.firstOrNull()?.message ?: "خطای نامشخص"
                log("ERROR", "Deploy", "Save failed for '$scriptName': $err")
                ApiResult.Error(err, resp.code())
            }
        } catch (e: Exception) {
            log("ERROR", "Deploy", "Exception saving script: ${e.message}")
            ApiResult.Error(e.message ?: "خطای شبکه هنگام ذخیره")
        }
    }

    suspend fun deleteWorker(accountId: String, scriptName: String): ApiResult<Unit> = safeCall("Workers") {
        api.deleteWorker(accountId, scriptName)
    }.let { result ->
        when (result) {
            is ApiResult.Success -> ApiResult.Success(Unit)
            is ApiResult.Error -> result
        }
    }

    // ---- Version history (local, Room) ----

    fun observeVersions(accountLabel: String, scriptName: String): Flow<List<WorkerVersionEntity>> =
        db.workerVersionDao().observeVersions(accountLabel, scriptName)

    suspend fun saveLocalVersion(accountLabel: String, scriptName: String, source: String, note: String) {
        db.workerVersionDao().insert(
            WorkerVersionEntity(
                accountLabel = accountLabel,
                scriptName = scriptName,
                source = source,
                note = note,
                createdAt = System.currentTimeMillis()
            )
        )
        db.workerVersionDao().trimTo(accountLabel, scriptName, keep = 20)
    }

    // ---- Services: KV / D1 / R2 / DNS / Pages ----

    suspend fun listKv(accountId: String) = safeCall("KV") { api.listKvNamespaces(accountId) }
    suspend fun listD1(accountId: String) = safeCall("D1") { api.listD1Databases(accountId) }
    suspend fun listR2(accountId: String) = safeCall("R2") { api.listR2Buckets(accountId) }
    suspend fun listZones() = safeCall("DNS") { api.listZones() }
    suspend fun listDnsRecords(zoneId: String) = safeCall("DNS") { api.listDnsRecords(zoneId) }
    suspend fun listPages(accountId: String) = safeCall("Pages") { api.listPagesProjects(accountId) }

    // ---- Logs ----

    fun observeLogs(): Flow<List<AppLogEntity>> = db.appLogDao().observeLogs()

    suspend fun clearLogs() = db.appLogDao().clear()

    private suspend fun log(level: String, tag: String, message: String) {
        db.appLogDao().insert(AppLogEntity(level = level, tag = tag, message = message, createdAt = System.currentTimeMillis()))
    }

    /** Wipes tokens, accounts, and local DB content (Settings -> "Delete all data"). */
    suspend fun wipeAllUserData() {
        tokenStore.clearAll()
        db.clearAllTables()
    }

    // ---- helpers ----

    private suspend fun <T> safeCall(tag: String, block: suspend () -> retrofit2.Response<CFEnvelope<T>>): ApiResult<T> {
        return try {
            val resp = block()
            val envelope = resp.body()
            if (resp.isSuccessful && envelope?.success == true && envelope.result != null) {
                ApiResult.Success(envelope.result)
            } else {
                val msg = envelope?.errors?.firstOrNull()?.message ?: "درخواست ناموفق بود (${resp.code()})"
                log("ERROR", tag, msg)
                ApiResult.Error(msg, resp.code())
            }
        } catch (e: Exception) {
            log("ERROR", tag, e.message ?: "خطای ناشناخته")
            ApiResult.Error(e.message ?: "خطای شبکه")
        }
    }
}
