package com.example.cfmanager.ui.components

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import com.example.cfmanager.ui.theme.*

/**
 * Lightweight, dependency-free syntax highlighter for JavaScript / TypeScript.
 * It tokenizes with a single ordered regex pass (comments/strings first, so
 * keywords inside them are never re-colored) and paints each match with the
 * corresponding VS-Code-Light-like color. Good enough for a mobile-first code
 * viewer/editor; not a full language server.
 */
object SyntaxHighlighter {

    private val KEYWORDS = setOf(
        "const", "let", "var", "function", "return", "if", "else", "for", "while",
        "do", "switch", "case", "break", "continue", "class", "extends", "new",
        "this", "import", "export", "from", "default", "async", "await", "try",
        "catch", "finally", "throw", "typeof", "instanceof", "in", "of", "yield",
        "interface", "type", "enum", "implements", "public", "private", "protected",
        "readonly", "static", "as", "null", "undefined", "true", "false", "void",
        "delete", "super", "get", "set"
    )

    private val TYPES = setOf(
        "string", "number", "boolean", "any", "unknown", "never", "object", "Array",
        "Promise", "Request", "Response", "Env", "ExecutionContext", "Record"
    )

    // Ordered: comment, string(single/double/template), number, word
    private val TOKEN_REGEX = Regex(
        """(//[^\n]*)|(/\*[\s\S]*?\*/)|("(?:[^"\\]|\\.)*")|('(?:[^'\\]|\\.)*')|(`(?:[^`\\]|\\.)*`)|(\b\d+(?:\.\d+)?\b)|([A-Za-z_$][A-Za-z0-9_$]*)"""
    )

    fun highlight(source: String): AnnotatedString = buildAnnotatedString {
        append(source)

        for (match in TOKEN_REGEX.findAll(source)) {
            val range = match.range
            val text = match.value
            val style: SpanStyle = when {
                match.groups[1] != null || match.groups[2] != null -> SpanStyle(color = SyntaxComment)
                match.groups[3] != null || match.groups[4] != null || match.groups[5] != null -> SpanStyle(color = SyntaxString)
                match.groups[6] != null -> SpanStyle(color = SyntaxNumber)
                match.groups[7] != null -> when (text) {
                    in KEYWORDS -> SpanStyle(color = SyntaxKeyword)
                    in TYPES -> SpanStyle(color = SyntaxType)
                    else -> if (text.isNotEmpty() && text[0].isUpperCase()) SpanStyle(color = SyntaxFunction)
                    else SpanStyle(color = SyntaxDefault)
                }
                else -> SpanStyle(color = SyntaxDefault)
            }
            addStyle(style, range.first, range.last + 1)
        }
    }
}
