package com.example.cfmanager.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.cfmanager.data.repository.CloudflareRepository
import com.example.cfmanager.ui.screens.editor.CodeEditorScreen
import com.example.cfmanager.ui.screens.editor.CodeEditorViewModel
import com.example.cfmanager.ui.screens.login.LoginScreen
import com.example.cfmanager.ui.screens.login.LoginViewModel
import com.example.cfmanager.util.SimpleViewModelFactory

@Composable
fun AppNavGraph(
    repository: CloudflareRepository
) {
    val navController = rememberNavController()

    // Resolved once login succeeds; both the account's Cloudflare Account ID
    // and its local label (used as the key for version history / logs).
    var activeAccountId by remember { mutableStateOf<String?>(null) }
    var activeAccountLabel by remember { mutableStateOf<String?>(null) }

    val startDestination = if (repository.activeAccountLabel() != null) Screen.Workers.route else Screen.Login.route

    NavHost(navController = navController, startDestination = startDestination) {

        composable(Screen.Login.route) {
            val loginViewModel: LoginViewModel = viewModel(factory = SimpleViewModelFactory(repository) { LoginViewModel(it) })
            LoginScreen(
                viewModel = loginViewModel,
                onConnected = {
                    val acc = repository.savedAccounts().firstOrNull { it.label == repository.activeAccountLabel() }
                    activeAccountId = acc?.accountId
                    activeAccountLabel = acc?.label
                    navController.navigate(Screen.Workers.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Workers.route) {
            // Resolve the active account fresh every time this destination is
            // entered (e.g. after switching accounts from Settings).
            val acc = repository.savedAccounts().firstOrNull { it.label == repository.activeAccountLabel() }
            val accountId = acc?.accountId
            val accountLabel = acc?.label

            if (accountId == null || accountLabel == null) {
                // No verified account id yet (e.g. token verify hadn't resolved account list) -> back to login.
                LoginScreenFallback(navController)
            } else {
                activeAccountId = accountId
                activeAccountLabel = accountLabel
                HomeShell(
                    repository = repository,
                    accountId = accountId,
                    accountLabel = accountLabel,
                    onOpenWorker = { scriptName -> navController.navigate(Screen.Editor.createRoute(scriptName)) },
                    onLoggedOutCompletely = {
                        navController.navigate(Screen.Login.route) {
                            popUpTo(0)
                        }
                    }
                )
            }
        }

        composable(
            route = Screen.Editor.route,
            arguments = listOf(navArgument("scriptName") { type = NavType.StringType })
        ) { backStackEntry ->
            val scriptName = backStackEntry.arguments?.getString("scriptName") ?: return@composable
            val accountId = activeAccountId
            val accountLabel = activeAccountLabel
            if (accountId != null && accountLabel != null) {
                val editorViewModel: CodeEditorViewModel = viewModel(factory = SimpleViewModelFactory(repository) { CodeEditorViewModel(it) })
                CodeEditorScreen(
                    viewModel = editorViewModel,
                    accountId = accountId,
                    accountLabel = accountLabel,
                    scriptName = scriptName,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}

@Composable
private fun LoginScreenFallback(navController: androidx.navigation.NavHostController) {
    androidx.compose.runtime.LaunchedEffect(Unit) {
        navController.navigate(Screen.Login.route) { popUpTo(0) }
    }
}
