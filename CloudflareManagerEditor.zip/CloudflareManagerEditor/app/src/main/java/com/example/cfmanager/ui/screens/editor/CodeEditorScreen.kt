package com.example.cfmanager.ui.screens.editor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.cfmanager.ui.components.CodeEditorView
import com.example.cfmanager.ui.components.CodeSearchBar
import com.example.cfmanager.ui.theme.StatusError
import com.example.cfmanager.ui.theme.StatusSuccess
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CodeEditorScreen(
    viewModel: CodeEditorViewModel,
    accountId: String,
    accountLabel: String,
    scriptName: String,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var showDeployWarning by remember { mutableStateOf(false) }
    var showVersionSheet by remember { mutableStateOf(false) }
    var showFontMenu by remember { mutableStateOf(false) }

    LaunchedEffect(scriptName) { viewModel.load(accountId, accountLabel, scriptName) }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = { Text(scriptName, maxLines = 1) },
                    navigationIcon = {
                        IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                    },
                    actions = {
                        IconButton(onClick = viewModel::undo, enabled = uiState.canUndo) {
                            Icon(Icons.Filled.Undo, contentDescription = "Undo")
                        }
                        IconButton(onClick = viewModel::redo, enabled = uiState.canRedo) {
                            Icon(Icons.Filled.Redo, contentDescription = "Redo")
                        }
                        IconButton(onClick = viewModel::toggleSearch) {
                            Icon(Icons.Filled.Search, contentDescription = "Search")
                        }
                        IconButton(onClick = { showFontMenu = true }) {
                            Icon(Icons.Filled.FormatSize, contentDescription = "Font size")
                        }
                        DropdownMenu(expanded = showFontMenu, onDismissRequest = { showFontMenu = false }) {
                            DropdownMenuItem(text = { Text("Increase size") }, onClick = { viewModel.setFontSize(uiState.fontSize + 1); showFontMenu = false })
                            DropdownMenuItem(text = { Text("Decrease size") }, onClick = { viewModel.setFontSize(uiState.fontSize - 1); showFontMenu = false })
                        }
                        IconButton(onClick = { showVersionSheet = true }) {
                            Icon(Icons.Filled.History, contentDescription = "Version history")
                        }
                    }
                )
                if (uiState.searchVisible) {
                    CodeSearchBar(
                        query = uiState.searchQuery,
                        matchCount = viewModel.matchCount(),
                        currentMatchIndex = uiState.currentMatchIndex,
                        onQueryChange = viewModel::onSearchQueryChange,
                        onNext = viewModel::searchNext,
                        onPrevious = viewModel::searchPrevious,
                        onClose = viewModel::toggleSearch
                    )
                }
            }
        },
        bottomBar = {
            BottomAppBar {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(onClick = { viewModel.saveLocalSnapshot() }) {
                        Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Save (local)")
                    }
                    Button(
                        onClick = { showDeployWarning = true },
                        enabled = uiState.saveState != SaveState.SAVING
                    ) {
                        if (uiState.saveState == SaveState.SAVING) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                            Spacer(Modifier.width(8.dp))
                        } else {
                            Icon(Icons.Filled.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                        }
                        Text("Deploy")
                    }
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when {
                uiState.isLoading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                uiState.errorMessage != null && uiState.fieldValue.text.isEmpty() -> Text(
                    uiState.errorMessage ?: "",
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.align(Alignment.Center).padding(24.dp)
                )
                else -> CodeEditorView(
                    value = uiState.fieldValue,
                    onValueChange = viewModel::onCodeChange,
                    fontSizeSp = uiState.fontSize,
                    modifier = Modifier.fillMaxSize()
                )
            }

            uiState.statusMessage?.let { msg ->
                StatusSnackbar(message = msg, isError = false, onDismiss = viewModel::clearStatus, modifier = Modifier.align(Alignment.BottomCenter))
            }
            if (uiState.errorMessage != null && uiState.fieldValue.text.isNotEmpty()) {
                StatusSnackbar(message = uiState.errorMessage ?: "", isError = true, onDismiss = viewModel::clearStatus, modifier = Modifier.align(Alignment.BottomCenter))
            }
        }
    }

    if (showDeployWarning) {
        AlertDialog(
            onDismissRequest = { showDeployWarning = false },
            icon = { Icon(Icons.Filled.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Deploy warning") },
            text = { Text("This will replace the current version of the Worker on Cloudflare and immediately affect live traffic. Are you sure?") },
            confirmButton = {
                TextButton(onClick = { showDeployWarning = false; viewModel.saveAndDeploy() }) {
                    Text("Yes, deploy", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { showDeployWarning = false }) { Text("Cancel") } }
        )
    }

    if (showVersionSheet) {
        VersionHistorySheet(
            viewModel = viewModel,
            onDismiss = { showVersionSheet = false },
            onRestore = { viewModel.restoreVersion(it); showVersionSheet = false }
        )
    }
}

@Composable
private fun StatusSnackbar(message: String, isError: Boolean, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    LaunchedEffect(message) {
        kotlinx.coroutines.delay(3000)
        onDismiss()
    }
    Surface(
        color = if (isError) StatusError else StatusSuccess,
        modifier = modifier.padding(16.dp)
    ) {
        Text(message, modifier = Modifier.padding(12.dp), color = androidx.compose.ui.graphics.Color.White)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VersionHistorySheet(
    viewModel: CodeEditorViewModel,
    onDismiss: () -> Unit,
    onRestore: (com.example.cfmanager.data.local.db.WorkerVersionEntity) -> Unit
) {
    val versions by viewModel.observeVersions().collectAsState(initial = emptyList())
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.ENGLISH) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Version history", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (versions.isEmpty()) {
                Text("No versions saved yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 400.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(versions) { v ->
                        ElevatedCard(onClick = { onRestore(v) }, modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(v.note, fontWeight = FontWeight.SemiBold)
                                Text(dateFormat.format(Date(v.createdAt)), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}
