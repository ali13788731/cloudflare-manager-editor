package com.example.cfmanager.ui.screens.editor

import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cfmanager.data.local.db.WorkerVersionEntity
import com.example.cfmanager.data.repository.ApiResult
import com.example.cfmanager.data.repository.CloudflareRepository
import com.example.cfmanager.util.UndoRedoStack
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class SaveState { IDLE, SAVING, SUCCESS, ERROR }

data class CodeEditorUiState(
    val isLoading: Boolean = true,
    val fieldValue: TextFieldValue = TextFieldValue(""),
    val isTypeScript: Boolean = false,
    val fontSize: Int = 14,
    val saveState: SaveState = SaveState.IDLE,
    val errorMessage: String? = null,
    val statusMessage: String? = null,
    val searchQuery: String = "",
    val searchVisible: Boolean = false,
    val currentMatchIndex: Int = -1,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false
)

class CodeEditorViewModel(private val repository: CloudflareRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(CodeEditorUiState())
    val uiState: StateFlow<CodeEditorUiState> = _uiState.asStateFlow()

    private val undoRedo = UndoRedoStack()
    private var accountId: String = ""
    private var accountLabel: String = ""
    private var scriptName: String = ""

    fun load(accountId: String, accountLabel: String, scriptName: String) {
        this.accountId = accountId
        this.accountLabel = accountLabel
        this.scriptName = scriptName
        this.uiState.value.let { }
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        _uiState.value = _uiState.value.copy(isTypeScript = scriptName.endsWith(".ts"))

        viewModelScope.launch {
            when (val result = repository.getWorkerSource(accountId, scriptName)) {
                is ApiResult.Success -> {
                    val tfv = TextFieldValue(result.data)
                    undoRedo.reset(result.data)
                    _uiState.value = _uiState.value.copy(isLoading = false, fieldValue = tfv)
                }
                is ApiResult.Error -> _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = result.message)
            }
        }
    }

    fun onCodeChange(newValue: TextFieldValue) {
        val textChanged = newValue.text != _uiState.value.fieldValue.text
        _uiState.value = _uiState.value.copy(fieldValue = newValue)
        if (textChanged) {
            undoRedo.push(newValue.text)
            _uiState.value = _uiState.value.copy(canUndo = undoRedo.canUndo(), canRedo = undoRedo.canRedo())
        }
    }

    fun undo() {
        val text = undoRedo.undo() ?: return
        _uiState.value = _uiState.value.copy(
            fieldValue = TextFieldValue(text, selection = androidx.compose.ui.text.TextRange(text.length)),
            canUndo = undoRedo.canUndo(),
            canRedo = undoRedo.canRedo()
        )
    }

    fun redo() {
        val text = undoRedo.redo() ?: return
        _uiState.value = _uiState.value.copy(
            fieldValue = TextFieldValue(text, selection = androidx.compose.ui.text.TextRange(text.length)),
            canUndo = undoRedo.canUndo(),
            canRedo = undoRedo.canRedo()
        )
    }

    fun setFontSize(size: Int) {
        _uiState.value = _uiState.value.copy(fontSize = size.coerceIn(10, 28))
    }

    fun toggleSearch() {
        val visible = !_uiState.value.searchVisible
        _uiState.value = _uiState.value.copy(searchVisible = visible, searchQuery = if (!visible) "" else _uiState.value.searchQuery)
    }

    fun onSearchQueryChange(query: String) {
        val matches = findMatches(query)
        _uiState.value = _uiState.value.copy(
            searchQuery = query,
            currentMatchIndex = if (matches.isEmpty()) -1 else 0
        )
    }

    fun searchNext() {
        val matches = findMatches(_uiState.value.searchQuery)
        if (matches.isEmpty()) return
        val next = (_uiState.value.currentMatchIndex + 1) % matches.size
        _uiState.value = _uiState.value.copy(currentMatchIndex = next)
    }

    fun searchPrevious() {
        val matches = findMatches(_uiState.value.searchQuery)
        if (matches.isEmpty()) return
        val prev = (_uiState.value.currentMatchIndex - 1 + matches.size) % matches.size
        _uiState.value = _uiState.value.copy(currentMatchIndex = prev)
    }

    fun matchCount(): Int = findMatches(_uiState.value.searchQuery).size

    private fun findMatches(query: String): List<Int> {
        if (query.isBlank()) return emptyList()
        val text = _uiState.value.fieldValue.text
        val indices = mutableListOf<Int>()
        var idx = text.indexOf(query, 0, ignoreCase = true)
        while (idx >= 0) {
            indices.add(idx)
            idx = text.indexOf(query, idx + 1, ignoreCase = true)
        }
        return indices
    }

    /** Local-only save: snapshot to Room version history (does not touch Cloudflare). */
    fun saveLocalSnapshot(note: String = "Manual save") {
        viewModelScope.launch {
            repository.saveLocalVersion(accountLabel, scriptName, _uiState.value.fieldValue.text, note)
            _uiState.value = _uiState.value.copy(statusMessage = "Local version saved.")
        }
    }

    /** Save + deploy to Cloudflare. Always snapshots locally first so a rollback point exists. */
    fun saveAndDeploy() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(saveState = SaveState.SAVING, errorMessage = null)
            repository.saveLocalVersion(accountLabel, scriptName, _uiState.value.fieldValue.text, "Before deploy")

            val result = repository.saveWorkerScript(
                accountId, scriptName, _uiState.value.fieldValue.text, _uiState.value.isTypeScript
            )
            when (result) {
                is ApiResult.Success -> _uiState.value = _uiState.value.copy(
                    saveState = SaveState.SUCCESS, statusMessage = "Saved and deployed successfully."
                )
                is ApiResult.Error -> _uiState.value = _uiState.value.copy(
                    saveState = SaveState.ERROR, errorMessage = result.message
                )
            }
        }
    }

    fun clearStatus() {
        _uiState.value = _uiState.value.copy(statusMessage = null, errorMessage = null, saveState = SaveState.IDLE)
    }

    fun observeVersions() = repository.observeVersions(accountLabel, scriptName)

    fun restoreVersion(version: WorkerVersionEntity) {
        val tfv = TextFieldValue(version.source)
        undoRedo.reset(version.source)
        _uiState.value = _uiState.value.copy(
            fieldValue = tfv,
            canUndo = undoRedo.canUndo(),
            canRedo = undoRedo.canRedo(),
            statusMessage = "Previous version restored (not yet deployed)."
        )
    }

    fun exportSource(): String = _uiState.value.fieldValue.text

    fun importSource(text: String) {
        val tfv = TextFieldValue(text)
        undoRedo.reset(text)
        _uiState.value = _uiState.value.copy(fieldValue = tfv, canUndo = undoRedo.canUndo(), canRedo = undoRedo.canRedo())
    }
}
