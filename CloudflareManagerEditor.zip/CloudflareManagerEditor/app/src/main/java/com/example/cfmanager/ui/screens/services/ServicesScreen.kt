package com.example.cfmanager.ui.screens.services

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.cfmanager.data.remote.dto.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServicesScreen(
    viewModel: ServicesViewModel,
    accountId: String,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    LaunchedEffect(accountId) { viewModel.init(accountId) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Cloudflare Services") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            ScrollableTabRow(selectedTabIndex = uiState.selectedTab.ordinal) {
                Tab(selected = uiState.selectedTab == ServiceTab.KV, onClick = { viewModel.selectTab(ServiceTab.KV) }, text = { Text("KV Namespaces") })
                Tab(selected = uiState.selectedTab == ServiceTab.D1, onClick = { viewModel.selectTab(ServiceTab.D1) }, text = { Text("D1 Database") })
                Tab(selected = uiState.selectedTab == ServiceTab.R2, onClick = { viewModel.selectTab(ServiceTab.R2) }, text = { Text("R2 Bucket") })
                Tab(selected = uiState.selectedTab == ServiceTab.DNS, onClick = { viewModel.selectTab(ServiceTab.DNS) }, text = { Text("DNS Records") })
                Tab(selected = uiState.selectedTab == ServiceTab.PAGES, onClick = { viewModel.selectTab(ServiceTab.PAGES) }, text = { Text("Pages") })
            }

            Box(modifier = Modifier.fillMaxSize()) {
                when {
                    uiState.isLoading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                    uiState.errorMessage != null -> Column(
                        modifier = Modifier.align(Alignment.Center).padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(uiState.errorMessage ?: "", color = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = viewModel::refreshCurrentTab) { Text("Retry") }
                    }
                    else -> when (uiState.selectedTab) {
                        ServiceTab.KV -> KvList(uiState.kv)
                        ServiceTab.D1 -> D1List(uiState.d1)
                        ServiceTab.R2 -> R2List(uiState.r2)
                        ServiceTab.DNS -> DnsSection(uiState, onZoneSelect = viewModel::selectZone)
                        ServiceTab.PAGES -> PagesList(uiState.pages)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyHint(text: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun KvList(items: List<CFKVNamespace>) {
    if (items.isEmpty()) { EmptyHint("No KV namespaces found."); return }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { ns ->
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(ns.title, fontWeight = FontWeight.SemiBold)
                    Text("ID: ${ns.id}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun D1List(items: List<CFD1Database>) {
    if (items.isEmpty()) { EmptyHint("No D1 databases found."); return }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { db ->
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(db.name, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Tables: ${db.num_tables ?: "-"} · Size: ${db.file_size?.let { "${it / 1024} KB" } ?: "-"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun R2List(items: List<CFR2Bucket>) {
    if (items.isEmpty()) { EmptyHint("No R2 buckets found."); return }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { bucket ->
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(bucket.name, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Created: ${bucket.creation_date?.take(10) ?: "-"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun DnsSection(uiState: ServicesUiState, onZoneSelect: (String) -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        if (uiState.zones.isNotEmpty()) {
            var expanded by remember { mutableStateOf(false) }
            val selectedZoneName = uiState.zones.firstOrNull { it.id == uiState.selectedZoneId }?.name ?: "Select domain"
            Box(modifier = Modifier.padding(12.dp)) {
                OutlinedButton(onClick = { expanded = true }) { Text(selectedZoneName) }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    uiState.zones.forEach { zone ->
                        DropdownMenuItem(text = { Text(zone.name) }, onClick = { onZoneSelect(zone.id); expanded = false })
                    }
                }
            }
        }
        if (uiState.dnsRecords.isEmpty()) {
            EmptyHint("No DNS records found.")
        } else {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(uiState.dnsRecords) { record ->
                    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("${record.type}  ${record.name}", fontWeight = FontWeight.SemiBold)
                                Text(record.content, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (record.proxied) {
                                Text("Proxied", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PagesList(items: List<CFPagesProject>) {
    if (items.isEmpty()) { EmptyHint("No Pages projects found."); return }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { project ->
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(project.name, fontWeight = FontWeight.SemiBold)
                    Text(
                        "${project.subdomain ?: "-"} · Branch: ${project.production_branch ?: "-"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
