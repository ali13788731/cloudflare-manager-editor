package com.example.cfmanager.ui.screens.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.cfmanager.data.local.db.AppLogEntity
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onLoggedOutCompletely: () -> Unit
) {
    val accounts = viewModel.accounts()
    val activeLabel = viewModel.activeLabel()
    var showWipeConfirm by remember { mutableStateOf(false) }
    var showLogs by remember { mutableStateOf(false) }

    Scaffold(topBar = { TopAppBar(title = { Text("Settings") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                SectionTitle("Cloudflare Accounts")
            }
            items(accounts) { acc ->
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(acc.label, fontWeight = FontWeight.SemiBold)
                            if (acc.label == activeLabel) {
                                Text("Active", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Row {
                            if (acc.label != activeLabel) {
                                TextButton(onClick = { viewModel.switchAccount(acc.label) }) { Text("Select") }
                            }
                            TextButton(onClick = { viewModel.removeAccount(acc.label) }) {
                                Text("Remove", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }

            item {
                SectionTitle("Security")
                ListItem(
                    headlineContent = { Text("View error logs") },
                    leadingContent = { Icon(Icons.Filled.BugReport, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth().clickableCard { showLogs = true }
                )
                ListItem(
                    headlineContent = { Text("Delete all user data") },
                    supportingContent = { Text("All tokens, accounts, and local history will be erased.") },
                    leadingContent = { Icon(Icons.Filled.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                    modifier = Modifier.fillMaxWidth().clickableCard { showWipeConfirm = true }
                )
            }

            item {
                Text(
                    "API tokens are stored only via EncryptedSharedPreferences on this device and are never included in app files or cloud backups.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    if (showWipeConfirm) {
        AlertDialog(
            onDismissRequest = { showWipeConfirm = false },
            icon = { Icon(Icons.Filled.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Delete all data") },
            text = { Text("This action cannot be undone and will erase all accounts, tokens, and local version history. Continue?") },
            confirmButton = {
                TextButton(onClick = {
                    showWipeConfirm = false
                    viewModel.wipeAll { onLoggedOutCompletely() }
                }) { Text("Delete everything", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { showWipeConfirm = false }) { Text("Cancel") } }
        )
    }

    if (showLogs) {
        LogViewerSheet(viewModel = viewModel, onDismiss = { showLogs = false })
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
}

private fun Modifier.clickableCard(onClick: () -> Unit): Modifier =
    this.clickable(onClick = onClick)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LogViewerSheet(viewModel: SettingsViewModel, onDismiss: () -> Unit) {
    val logs by viewModel.logs().collectAsState(initial = emptyList())
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.ENGLISH) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Log Viewer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                TextButton(onClick = { viewModel.clearLogs() }) { Text("Clear") }
            }
            if (logs.isEmpty()) {
                Text("No logs recorded yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 400.dp)) {
                    items(logs) { log -> LogRow(log, dateFormat) }
                }
            }
        }
    }
}

@Composable
private fun LogRow(log: AppLogEntity, dateFormat: SimpleDateFormat) {
    val color = when (log.level) {
        "ERROR" -> MaterialTheme.colorScheme.error
        "WARN" -> androidx.compose.ui.graphics.Color(0xFFD29922)
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Text("[${log.level}] ${log.tag} · ${dateFormat.format(Date(log.createdAt))}", color = color, style = MaterialTheme.typography.labelSmall)
        Text(log.message, style = MaterialTheme.typography.bodySmall)
    }
}
