package com.example.cfmanager.ui.theme

import androidx.compose.ui.graphics.Color

// Cloudflare-orange accent on a light neutral scale.
val CFOrange = Color(0xFFF6821F)
val CFOrangeDark = Color(0xFFCC6F1A)

val EditorBgLight = Color(0xFFFFFFFF)
val EditorSurfaceLight = Color(0xFFF3F3F3)
val EditorLineNumberLight = Color(0xFF9CA0A6)
val EditorGutterLight = Color(0xFFEDEDED)

// Syntax colors (roughly VS Code Light+ theme).
val SyntaxKeyword = Color(0xFF0000FF)
val SyntaxString = Color(0xFFA31515)
val SyntaxComment = Color(0xFF008000)
val SyntaxNumber = Color(0xFF098658)
val SyntaxFunction = Color(0xFF795E26)
val SyntaxType = Color(0xFF267F99)
val SyntaxDefault = Color(0xFF1E1E1E)

val StatusSuccess = Color(0xFF3FB950)
val StatusError = Color(0xFFF85149)
val StatusWarning = Color(0xFFD29922)
