package com.example.cfmanager.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

// The app ships with a single, fixed light theme — no dark mode, no
// system-theme following, no dynamic color. One palette to maintain and
// no chance of a screen mixing colors from two different schemes.
private val AppColors = lightColorScheme(
    primary = CFOrange,
    secondary = CFOrangeDark,
    background = EditorBgLight,
    surface = EditorSurfaceLight,
    error = StatusError
)

@Composable
fun CFManagerTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AppColors,
        typography = AppTypography,
        content = content
    )
}
